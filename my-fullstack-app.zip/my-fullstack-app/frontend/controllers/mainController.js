angular.module('myApp')
    .controller('MainController', function($scope, ItemService) {
        $scope.items = [];

        $scope.loadItems = function() {
            ItemService.getItems().then(function(response) {
                $scope.items = response.data;
            });
        };

        $scope.addItem = function() {
            if (!$scope.newItem || !$scope.newItem.name || !$scope.newItem.description) return;
            console.log("Sending:", $scope.newItem);
            ItemService.addItem($scope.newItem).then(function(response) {
                console.log("Got:", response.data);
                $scope.items.push(response.data);
                $scope.newItem = {};
            });
        };

        $scope.loadItems();
    });