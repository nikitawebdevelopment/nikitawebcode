angular.module('myApp')
    .factory('ItemService', function($http) {
        return {
            getItems: function() {
                return $http.get('/api/items');
            },
            addItem: function(item) {
                return $http.post('/api/items', item);
            }
        };
    });