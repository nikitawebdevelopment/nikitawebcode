const express = require('express');
const router = express.Router();
const Item = require('../models/Item');

router.get('/', async(req, res) => {
    try {
        const items = await Item.find();
        res.json(items);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/', async(req, res) => {
    console.log("POST body:", req.body);
    try {
        const newItem = new Item(req.body);
        await newItem.save();
        res.status(201).json(newItem);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

module.exports = router;